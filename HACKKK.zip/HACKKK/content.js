// Grammerly AI Content Script

let activeTooltip = null;
let scanTimeout = null;

console.log("Grammerly AI: Content script loaded.");

// 1. INPUT DETECTION
document.addEventListener('input', (e) => {
    const target = e.target;
    // Check if it's an editable field
    if (target.matches('textarea, input[type="text"], [contenteditable="true"]')) {
        handleInput(target);
    }
});

// Debounced input handler
function handleInput(target) {
    if (scanTimeout) clearTimeout(scanTimeout);

    // Show 'scanning' state immediately
    showStatusIcon(target, 'scanning');

    scanTimeout = setTimeout(() => {
        scanField(target);
    }, 500); // 500ms debounce
}

// 2. SCANNING LOGIC
function scanField(target) {
    let text = "";
    if (target.value !== undefined) {
        text = target.value;
    } else if (target.isContentEditable) {
        text = target.innerText;
    }

    if (!text || text.trim().length === 0) {
        removeStatusIcon(target);
        return;
    }

    // Send to background for checking
    chrome.runtime.sendMessage({
        action: "check_grammar",
        text: text
    }, (response) => {
        if (chrome.runtime.lastError) {
            console.error("Grammerly Error:", chrome.runtime.lastError);
            return;
        }

        if (response && response.issues) {
            highlightIssues(target, response.issues);
            showStatusIcon(target, response.issues.length > 0 ? 'error' : 'success');
        }
    });
}

// 3. HIGHLIGHTING SYSTEM
function highlightIssues(target, issues) {
    // Basic visual cue on the element itself
    if (issues.length > 0) {
        target.style.borderBottom = "2px dotted #ff4b4b";
        target.style.backgroundColor = "rgba(255, 75, 75, 0.05)";
    } else {
        target.style.borderBottom = "";
        target.style.backgroundColor = "";
    }

    // Store issues on the element data
    target.dataset.grammarIssues = JSON.stringify(issues);

    // Add listener for click to show tooltip
    // Remove old listener to prevent duplicates? (Hard with anonymous functions, 
    // but we can just add it once or use a named function if we want to be strict.
    // For now, this is okay as we are replacing the logic entirely).
    target.addEventListener('click', (e) => {
        // Only show if issues exist
        const currentIssues = JSON.parse(target.dataset.grammarIssues || "[]");
        if (currentIssues.length > 0) {
            showTooltip(target, currentIssues);
        }
    });
}

// 4. STATUS ICON SYSTEM (The "G" Button)
function showStatusIcon(target, status) {
    let parent = target.parentElement;
    // Ensure parent is positioned to hold absolute child
    const style = window.getComputedStyle(parent);
    if (style.position === 'static') {
        parent.style.position = 'relative';
    }

    let icon = parent.querySelector('.grammerly-status-icon');

    if (!icon) {
        icon = document.createElement('div');
        icon.className = 'grammerly-status-icon';
        icon.style.cssText = `
            position: absolute;
            bottom: 8px;
            right: 8px;
            width: 24px;
            height: 24px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            cursor: pointer;
            z-index: 1000;
            transition: all 0.2s;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        `;
        parent.appendChild(icon);

        // Click icon to show tooltip too
        icon.addEventListener('click', (e) => {
            e.stopPropagation(); // Prevent parent click
            const currentIssues = JSON.parse(target.dataset.grammarIssues || "[]");
            if (currentIssues.length > 0) {
                showTooltip(target, currentIssues);
            }
        });
    }

    if (status === 'scanning') {
        icon.innerText = '🔄';
        icon.style.background = '#f0f0f0';
        icon.style.animation = 'spin 1s linear infinite';
    } else if (status === 'error') {
        icon.innerText = '1'; // active count (simplified)
        icon.style.background = '#ff4b4b';
        icon.style.color = 'white';
        icon.style.animation = 'none';
        icon.title = "Issues found";
    } else {
        icon.innerText = '✓';
        icon.style.background = '#28a745';
        icon.style.color = 'white';
        icon.style.animation = 'none';
        icon.title = "All good";
    }
}

function removeStatusIcon(target) {
    const icon = target.parentElement.querySelector('.grammerly-status-icon');
    if (icon) icon.remove();
    target.style.borderBottom = "";
    target.style.backgroundColor = "";
}


// 5. TOOLTIP UI
function showTooltip(target, issues) {
    if (activeTooltip) activeTooltip.remove();

    const rect = target.getBoundingClientRect();
    const tooltip = document.createElement('div');
    tooltip.className = 'grammerly-tooltip'; // Styles in styles.css

    let html = `<div class="grammerly-header">Found ${issues.length} issues</div>`;

    issues.forEach((issue, index) => {
        html += `
            <div class="grammerly-issue-card">
                <div class="grammerly-desc">${issue.description}</div>
                <div class="grammerly-suggestion">
                    <span class="suggestion-text">${issue.recommendation}</span>
                    <button class="grammerly-fix-btn" data-idx="${index}">Apply Fix</button>
                </div>
            </div>
        `;
    });

    tooltip.innerHTML = html;

    // Position tooltip
    tooltip.style.top = `${rect.bottom + window.scrollY + 8}px`;
    tooltip.style.left = `${rect.left + window.scrollX}px`;

    document.body.appendChild(tooltip);
    activeTooltip = tooltip;

    // Add fix listeners
    const buttons = tooltip.querySelectorAll('.grammerly-fix-btn');
    buttons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const idx = parseInt(e.target.dataset.idx);
            applyFix(target, issues[idx]);
            tooltip.remove();
            activeTooltip = null;
        });
    });

    // Close on outside click
    setTimeout(() => {
        document.addEventListener('click', closeTooltipOutside);
    }, 0);
}

function closeTooltipOutside(e) {
    if (activeTooltip && !activeTooltip.contains(e.target) && !e.target.closest('.grammerly-status-icon')) {
        activeTooltip.remove();
        activeTooltip = null;
        document.removeEventListener('click', closeTooltipOutside);
    }
}

function applyFix(target, issue) {
    let text = target.value !== undefined ? target.value : target.innerText;

    if (issue.index >= 0 && issue.length > 0) {
        const before = text.substring(0, issue.index);
        const after = text.substring(issue.index + issue.length);
        const newText = before + issue.recommendation + after;

        if (target.value !== undefined) {
            target.value = newText;
        } else {
            target.innerText = newText;
        }

        // Re-scan
        handleInput(target);
    }
}

// 6. LISTEN FOR POPUP TRIGGERS
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "scan_page") {
        const inputs = document.querySelectorAll('textarea, input[type="text"]');
        let count = 0;
        inputs.forEach(input => {
            scanField(input);
            count++;
        });
        sendResponse({ status: "scanned", count: count });
    }
});
