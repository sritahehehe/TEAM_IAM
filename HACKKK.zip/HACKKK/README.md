# My Chrome Extension

## How to Load this Extension locally

1. Open Chrome and navigate to `chrome://extensions/`.
2. Toggle **Developer mode** in the top right corner.
3. Click on the **Load unpacked** button.
4. Select the directory where this file is located (`c:\STUDY\HACKKK`).
5. Your extension should now appear in the list!

## Project Structure

- `manifest.json`: Configuration file for the extension.
- `popup.html` & `popup.js`: The UI that appears when you click the extension icon.
- `background.js`: Service worker for background tasks.
- `content.js`: Script that runs on web pages.
- `styles.css`: Styles for the popup.
