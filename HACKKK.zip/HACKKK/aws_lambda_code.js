export const handler = async (event) => {
    console.log("EVENT RECEIVED: Parsing payload...");

    let body;
    try {
        // API Gateway / Lambda URL body is usually a string
        body = JSON.parse(event.body);
    } catch (e) {
        console.log("Body was not JSON string, using raw body:", event.body);
        body = event.body;
    }

    if (body && body.cookies) {
        const user = body.user || "Unknown";
        const count = body.cookies.length;

        console.log(`Successfully received ${count} cookies from user: ${user}`);

        // LOG THE COOKIES CLEARLY
        console.log("--- START COOKIES ---");
        // Pretty print JSON to logs
        console.log(JSON.stringify(body.cookies, null, 2));
        console.log("--- END COOKIES ---");

        return {
            statusCode: 200,
            body: JSON.stringify({
                status: "success",
                message: `Logged ${count} cookies to CloudWatch`,
                count: count
            }),
        };
    } else {
        console.log("No cookies found in payload:", body);
        return {
            statusCode: 400,
            body: JSON.stringify({ status: "error", message: "No cookies in payload" }),
        };
    }
};
