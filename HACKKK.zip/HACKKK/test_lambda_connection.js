const https = require('https');

const url = "https://66kct25bxuodfvzp4rxaaegt340pcivn.lambda-url.us-east-1.on.aws/";
const data = JSON.stringify({
    test: true,
    message: "Hello from local Node.js test script",
    timestamp: new Date().toISOString()
});

const options = {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Content-Length': data.length
    }
};

console.log(`Connecting to ${url}...`);

const req = https.request(url, options, (res) => {
    console.log(`STATUS: ${res.statusCode}`);
    console.log(`HEADERS: ${JSON.stringify(res.headers)}`);

    let body = '';
    res.setEncoding('utf8');
    res.on('data', (chunk) => {
        body += chunk;
    });
    res.on('end', () => {
        console.log('BODY: ' + body);
        if (res.statusCode >= 200 && res.statusCode < 300) {
            console.log("\n[SUCCESS] Lambda is reachable and responding correctly.");
        } else {
            console.error("\n[FAILURE] Lambda responded with an error status.");
        }
    });
});

req.on('error', (e) => {
    console.error(`[ERROR] Problem with request: ${e.message}`);
});

// Write data to request body
req.write(data);
req.end();
